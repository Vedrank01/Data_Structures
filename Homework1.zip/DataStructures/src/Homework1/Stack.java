package Homework1;

public class Stack <Item> {
	public class Node <Item>{
		Item data;
		Node<Item> next;
	}
		private Node<Item> top = null;
	    private int size = 0;
	 
	    
	 
	    public void push(Item item) {
	    Node <Item>	newNode = new Node<Item>();
	    newNode.data=item;
	    newNode.next = top;                    
	    top = newNode;                         
	    size++;                                 
	}
	    
	    
	
	    public boolean isEmpty() {
	    	
			return size == 0;
	    }
	    
	    
	    public Item pop() {
	    	 if (top == null) {                                                     
	 	        throw new IndexOutOfBoundsException("The Stack is empty.");   
	 	    }                                                                    
	    	Item data=top.data;
	    	top=top.next;
	    	size--;
	        return data;
	    }
	    
	    
	    public int size() {
	    	
	        return size;
	    }
	}

