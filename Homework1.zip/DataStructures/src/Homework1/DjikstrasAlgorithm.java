package Homework1;
import java.util.Scanner;
public class DjikstrasAlgorithm {
public static void main(String[] args)  {
			
		
		Stack<Double> values=new Stack<Double>();
		Stack<String> operators=new Stack<String>();
		System.out.println("Enter an arithmetic expression");
		Scanner expr=new Scanner(System.in);
		String[] expression = expr.nextLine().split(" ");
		
		for(int i=0;i<expression.length;i++) {
			if(expression[i].equals("+")) operators.push(expression[i]);
			else if(expression[i].equals("-")) operators.push(expression[i]);
			else if(expression[i].equals("*")) operators.push(expression[i]);
			else if(expression[i].equals("/")) operators.push(expression[i]);
			else if(expression[i].equals("%")) operators.push(expression[i]);
			else if(expression[i].equals("(")) continue;
			else if(expression[i].equals(")")) {
				
				String operator=operators.pop();
				double value=values.pop();
				
				if(operator.equals("+"))   value=values.pop()+(value);
				else if(operator.equals("-"))   value=values.pop()-(value);
				else if(operator.equals("*"))   value=values.pop()*(value);
				else if(operator.equals("/"))   value=values.pop()/(value);
				else if(operator.equals("%"))   value=values.pop()%(value);
				values.push(value);
				
			}
			else values.push(Double.parseDouble(expression[i]));
		}
		 System.out.println(values.pop());

	}
}


